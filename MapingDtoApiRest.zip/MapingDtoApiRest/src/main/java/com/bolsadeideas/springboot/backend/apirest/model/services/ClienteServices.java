package com.bolsadeideas.springboot.backend.apirest.model.services;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.bolsadeideas.springboot.backend.apirest.DTO.ClienteDTO;
import com.bolsadeideas.springboot.backend.apirest.model.dao.IClienteDao;
import com.bolsadeideas.springboot.backend.apirest.model.entity.Cliente;

@Service
public class ClienteServices   {

	@Autowired
	private IClienteDao clienteDAO;
	
	
	public List<ClienteDTO> findAll() {
	
		List<Cliente> cliente = clienteDAO.findAll();
		
		ModelMapper modelMapper = new ModelMapper(); 
		
		List<ClienteDTO> clienteDTO = new ArrayList<>();
		
		
		cliente.forEach(Cliente -> {
			ClienteDTO recorrerClienteDTO = modelMapper.map(Cliente, ClienteDTO.class);
			
			recorrerClienteDTO.setEdad();
			
			clienteDTO.add(recorrerClienteDTO);
		});
		
		return clienteDTO;
	}


	
	public Cliente findById(Long id) {
		
		return clienteDAO.findById(id).orElse(null);
	}


	
	public Cliente save(Cliente cliente) {
		
		
		
		
		return clienteDAO.save(cliente);
	}


	
	public void delete(Long id) {
		clienteDAO.deleteById(id);
		
	}

}
