package com.bolsadeideas.springboot.backend.apirest.DTO;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;

@Data
public class ClienteDTO {

	
	private long id;
	private String nombre;
	private String apellido;
	private String email;
	
	@Setter(AccessLevel.NONE)
	private long edad;
	
	
	public void setEdad() {
		this.edad = 20;
	}
	
	
	
	
}
