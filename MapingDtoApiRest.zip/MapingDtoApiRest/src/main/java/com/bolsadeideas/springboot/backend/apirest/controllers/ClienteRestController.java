package com.bolsadeideas.springboot.backend.apirest.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bolsadeideas.springboot.backend.apirest.DTO.ClienteDTO;
import com.bolsadeideas.springboot.backend.apirest.model.entity.Cliente;
import com.bolsadeideas.springboot.backend.apirest.model.services.ClienteServices;


@CrossOrigin(origins = {"http://localhost:4200"} )
@RestController
@RequestMapping("/api")
public class ClienteRestController {

	@Autowired
	private ClienteServices servicioCliente;
	
	//-----------Listar Usuarios---------------------//
	@RequestMapping(value = "/clientes" , method = RequestMethod.GET )
	public List<ClienteDTO> index(){
		return servicioCliente.findAll();
	}
	//----------------------------------------------//
	
	
	
	//----------------buscar por id un registro--------//
	@RequestMapping( value =  "/clientes/{id}" , method = RequestMethod.GET )
	public ResponseEntity<?> mostrarPorId(@PathVariable Long id) {
		
		Cliente cliente = null;
		Map<String, Object> respuesta  = new HashMap<>();
		
		try {
			 cliente = servicioCliente.findById(id);
		} catch (DataAccessException e) {
			respuesta.put("mensaje",  "error al realizar la consulta");
			respuesta.put("error", e.getMessage() + ":" + e.getMostSpecificCause().getMessage());
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		if(cliente == null) {
			respuesta.put("mensaje", "no existen registros con el id " + id);
			return new ResponseEntity<Map<String, Object>>(respuesta,HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Cliente>(cliente, HttpStatus.OK);
	}
	//---------------------------------------------------------//
	
	
	
	
	//----------------------Insertar un nuevo cliente---------------------//
	@RequestMapping(value = "/clientes", method = RequestMethod.POST )
	public ResponseEntity<?> crear(@Valid @RequestBody  Cliente cliente) {
		
		
		Cliente clienteNew = null;
		Map<String, Object> respuesta  = new HashMap<>();
		
		if(cliente.getNombre()=="" || cliente.getApellido()=="" || cliente.getEmail()=="" ) {
			
			respuesta.put("mensaje", "Por favor llene todos los campos");
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.BAD_REQUEST);
		}
		
		
		try {
			clienteNew = servicioCliente.save(cliente);
		} catch (DataAccessException e) {
			respuesta.put("mensaje",  "error al realizar insertar");
			respuesta.put("error AL INSERTAR", e.getMessage() + ":" + e.getMostSpecificCause().getMessage());
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		respuesta.put("mensaje", "el cliente ha sido creado con exito");
		respuesta.put("cliente", clienteNew);
		return new ResponseEntity<Map<String, Object>>(respuesta,HttpStatus.CREATED);
	}
	//-----------------------------------------------------//
	
	
	
	//--------------------actualizar cliente----------------//
	@RequestMapping(value = "/clientes/{id}", method = RequestMethod.PUT )
	public ResponseEntity<?> actualizar(@RequestBody Cliente cliente, @PathVariable Long id) {
		
		Cliente clienteActual = servicioCliente.findById(id);
		
		Cliente clienteActualizar = null;
		
		Map<String, Object> respuesta  = new HashMap<>();
		
		try {
			
			clienteActual.setApellido(cliente.getApellido());
			clienteActual.setNombre(cliente.getNombre());
			clienteActual.setEmail(cliente.getEmail());
			
			clienteActualizar = servicioCliente.save(clienteActual);
			
		} catch (DataAccessException e) {
			respuesta.put("mensaje",  "error al actualizar el cliente en la base de datos");
			respuesta.put("error AL Actualizar", e.getMessage() + ":" + e.getMostSpecificCause().getMessage());
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
		
		respuesta.put("mensaje", "el cliente ha sido actualizado con exito");
		respuesta.put("cliente", clienteActualizar);
		return new ResponseEntity<Map<String, Object>>(respuesta,HttpStatus.CREATED);
		
	}
	//------------------------------------------------//
	
	
	
	//-------------------eliminar un cliente--------------------//
	@RequestMapping(value = "/clientes/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<?> delete(@PathVariable Long id) {
		
		
		Map<String, Object> respuesta  = new HashMap<>();
		
		try {
			servicioCliente.delete(id);
		} catch (DataAccessException e) {
			respuesta.put("mensaje",  "error al eliminar el cliente en la base de datos");
			respuesta.put("error AL Actualizar", e.getMessage() + ":" + e.getMostSpecificCause().getMessage());
			return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
		respuesta.put("mensaje", "el cliente ha sido eliminado con exito");
		return new ResponseEntity<Map<String, Object>>(respuesta, HttpStatus.OK);
		
		
	}
	//------------------------------------------------------------//
	
}
